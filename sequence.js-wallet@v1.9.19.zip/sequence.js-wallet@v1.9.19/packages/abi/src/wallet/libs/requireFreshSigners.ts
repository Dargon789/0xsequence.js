export const abi = [
  {
    inputs: [
      {
        internalType: 'address',
        name: '',
        type: 'address'
      }
    ],
    name: 'requireFreshSigner',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function'
  }
]
