@0xsequence/network
===================

See [0xsequence project page](https://github.com/0xsequence/sequence.js).
