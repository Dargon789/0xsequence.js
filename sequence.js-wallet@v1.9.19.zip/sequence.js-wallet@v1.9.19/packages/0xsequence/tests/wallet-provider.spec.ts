import { runBrowserTests } from './utils/browser-test-runner'

runBrowserTests('wallet-provider/dapp', 'wallet-provider/dapp.test.html')
runBrowserTests('wallet-provider/dapp2', 'wallet-provider/dapp2.test.html')
