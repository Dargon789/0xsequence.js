import { runBrowserTests } from './utils/browser-test-runner'

runBrowserTests('mock-wallet', 'mock-wallet/mock-wallet.test.html')
