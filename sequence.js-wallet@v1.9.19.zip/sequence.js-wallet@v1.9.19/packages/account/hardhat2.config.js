
module.exports = {
  networks: {
    hardhat: {
      chainId: 31338,
      accounts: {
        mnemonic: 'ripple axis someone ridge uniform wrist prosper there frog rate olympic knee'
      }
    }
  }
}
