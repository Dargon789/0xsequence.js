@0xsequence/metadata
====================

See [0xsequence project page](https://github.com/0xsequence/sequence.js).
