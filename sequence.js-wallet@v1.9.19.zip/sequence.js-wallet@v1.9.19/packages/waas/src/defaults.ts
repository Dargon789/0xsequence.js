// todo: add production template
/*export const PROD = {
}*/

// next
export const TEST = {
  rpcServer: 'https://d14tu8valot5m0.cloudfront.net',
  emailRegion: 'us-east-2'
}

export const LOCAL = {
  rpcServer: 'http://localhost:9123',
  emailRegion: 'us-east-2'
}
