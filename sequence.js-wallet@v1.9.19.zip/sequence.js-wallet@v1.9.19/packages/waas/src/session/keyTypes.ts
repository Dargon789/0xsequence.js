export enum KeyTypes {
  ECDSAP256K1 = 0,
  ECDSAP256R1 = 1
}
